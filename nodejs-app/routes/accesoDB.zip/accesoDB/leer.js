"use strict";

const express = require("express");
const mysql = require("mysql2");
const router = express.Router();
const dbConfig = require("../config/db.config");

const connection = mysql.createConnection(dbConfig.accesoDB);

router.post("/leer", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.json({ ok: false, mensaje: "Faltan credenciales" });
  }

  const sql =
    "SELECT id, username, nombre FROM usuarios WHERE username = ? AND password = ?";
  connection.query(sql, [username, password], (err, rows) => {
    if (err) return res.status(500).json(err);

    if (rows.length === 0) {
      return res.json({ ok: false });
    }

    res.json({ ok: true, usuario: rows[0] });
  });
});

module.exports = router;
