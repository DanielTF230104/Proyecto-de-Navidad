"use strict";

const express = require("express");
const mysql = require("mysql2");
const router = express.Router();
const dbConfig = require("../config/db.config");

const connection = mysql.createConnection(dbConfig.accesoDB);

router.post("/grabar", (req, res) => {
  const { username, password, nombre } = req.body;

  if (!username || !password || !nombre) {
    return res.json({ ok: false, mensaje: "Faltan datos" });
  }

  const sqlExiste = "SELECT id FROM usuarios WHERE username = ?";
  connection.query(sqlExiste, [username], (err, rows) => {
    if (err) return res.status(500).json(err);

    if (rows.length > 0) {
      return res.json({ ok: false, mensaje: "Usuario ya existe" });
    }

    const sqlInsert =
      "INSERT INTO usuarios (username, password, nombre) VALUES (?, ?, ?)";
    connection.query(sqlInsert, [username, password, nombre], (err) => {
      if (err) return res.status(500).json(err);

      res.json({ ok: true });
    });
  });
});

module.exports = router;
