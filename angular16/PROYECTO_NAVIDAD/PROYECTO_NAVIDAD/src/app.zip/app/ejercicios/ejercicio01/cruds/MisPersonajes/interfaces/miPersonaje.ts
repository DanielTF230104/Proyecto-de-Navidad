export interface MiPersonaje {
    id?: number;  // ID de la base de datos
    name: string;
    ki?: string | number;
}