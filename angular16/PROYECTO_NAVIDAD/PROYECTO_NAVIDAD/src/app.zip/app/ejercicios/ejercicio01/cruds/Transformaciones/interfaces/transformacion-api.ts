export interface TransformacionAPI {
  id: number;
  name: string;
  ki?: string | number;
  image: string;
}