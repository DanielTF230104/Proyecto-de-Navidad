export interface FiltrosAPI {
    gender: string; // Género del personaje
    race: string;   // Raza del personaje
    affiliation: string; // Afiliación del personaje
}
