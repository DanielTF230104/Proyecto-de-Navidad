export interface AuthResponse {
  ok: boolean;
  usuario?: {
    id: number;
    username: string;
    nombre: string;
  };
  mensaje?: string;
}