import { Component } from '@angular/core';
import { AuthService } from 'src/app/servicios/auth.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent {
  nombre: string = '';
  username: string = '';
  password: string = '';
  
  constructor(private authService: AuthService) { }

  registrar() {
    this.authService.registro(this.nombre, this.username, this.password);
  };
}
