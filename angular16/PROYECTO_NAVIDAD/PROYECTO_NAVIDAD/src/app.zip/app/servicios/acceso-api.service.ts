import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthResponse } from '../interfaces/auth-response';

@Injectable({
  providedIn: 'root'
})
export class AccesoApiService {
  private baseUrl: string = 'http://localhost:3000/accesoDB';

  constructor(private http: HttpClient) { }

  login(username: string, password: string) {
    const url = `${this.baseUrl}/leer`;
    return this.http.post<AuthResponse>(url, { username, password }
    );
  }

  registro(nombre: string, username: string, password: string) {
    const url = `${this.baseUrl}/grabar`;
    return this.http.post<AuthResponse>(url, { nombre, username, password }
    );
  }
}
