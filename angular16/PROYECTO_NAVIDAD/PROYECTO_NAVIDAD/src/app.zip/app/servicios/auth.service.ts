import { Injectable, signal } from '@angular/core';
import { AccesoApiService } from './acceso-api.service';
import { Router } from '@angular/router';
import { AuthResponse } from '../interfaces/auth-response';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public isLoggedIn = signal<boolean>(false);
  /*   isLoggedIn = this._isLoggedIn.asReadonly(); */

  public usuario = signal<any>(null);
  /*   usuario = this._usuario.asReadonly(); */

  constructor(
    private accesoApi: AccesoApiService,
    private router: Router
  ) { }

  login(username: string, password: string) {
    this.accesoApi.login(username, password)
      .subscribe({
        next: (response) => {
          if (response.ok) {
            this.isLoggedIn.set(true);
            this.usuario.set(response.usuario);
            this.router.navigate(['/inicio']);
          } else {
            this.isLoggedIn.set(false);
            this.usuario.set(null);
          }
        },
        error: () => {
          this.isLoggedIn.set(false);
          this.usuario.set(null);
        }
      });
  }

  registro(nombre: string, username: string, password: string) {
    this.accesoApi.registro(nombre, username, password)
      .subscribe({
        next: (response) => {
          if (response.ok) {
            this.router.navigate(['/login']);
          }
        },
        error: () => {
          console.error('Error en el registro');
        }
      });
  }

  logout() {
    this.isLoggedIn.set(false);
    this.usuario.set(null);
    this.router.navigate(['/login']);
  }
}
